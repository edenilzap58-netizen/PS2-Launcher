# Customizações aplicadas

## 1. Cor do texto: azul claro
Arquivo: `src/gui.c` (perto da linha 1339)
```c
u8 gUiTextColorR = 0x40;
u8 gUiTextColorG = 0xC0;
u8 gUiTextColorB = 0xFF;
```
Para mudar de novo, é só editar esses 3 valores (0x00 a 0xFF) e recompilar.
Isso afeta o texto/ícones em destaque em toda a interface moderna do launcher.

## 2. Papel de parede
- Imagem: `gfx/wallpaper.png` (já substituída pela sua arte, recortada/redimensionada para 640x448)
- Controlado por `gUseCustomWallpaper` e `gWallpaperDimAlpha` em `src/gui.c` (perto da linha 1344):
  - `gUseCustomWallpaper = 1` → mostra o papel de parede (0 = volta ao fundo padrão)
  - `gWallpaperDimAlpha = 0x40` → escurece a imagem para o texto continuar legível
    (0x00 = imagem 100% visível, 0x80 = totalmente preto)

Para trocar a imagem de novo: substitua `gfx/wallpaper.png` por outro PNG (ideal: até
1024x1024, sem exagerar para não estourar a VRAM do PS2) e recompile.

## 3. Botão de Desligar / Reiniciar
Agora é só apertar **SELECT** em qualquer tela do launcher (Games, Apps ou
Settings) para abrir um menu com 3 opções:
- **Restart** → reinicia (volta pro menu de sistema do PS2 / OSDSYS)
- **Power Off** → desliga o console de verdade
- **Cancel** → fecha o menu sem fazer nada

Use ← / → para navegar entre as opções e X para confirmar (○ ou △ cancela
direto). Também tem uma dica "SELECT  Power" no canto superior direito da
tela pra lembrar do atalho.

Arquivos alterados: `src/menusys.c` (lógica do menu e do botão SELECT),
`src/themes.c` (desenho do popup), `src/system.c`/`include/system.h`
(função `sysReboot()` nova).

## Como compilar
Você precisa do toolchain **ps2dev/ps2sdk**. Forma mais simples (Docker):

```bash
docker run --rm -v "$PWD":/src -w /src ps2dev/ps2dev make
```

Isso vai gerar o `PS2L.ELF` (ou nome parecido, veja `EE_BIN_PACKED` no Makefile) na
pasta do projeto. Copie esse arquivo pro seu USB/HDD do PS2 no lugar do ELF antigo.

Se preferir instalar localmente (sem Docker):
https://github.com/ps2dev/ps2dev — siga o "Quickstart" de instalação do SDK.
