#ifndef __CUSTOM_THEME_H
#define __CUSTOM_THEME_H

#include "include/renderman.h"

// ---------------------------------------------------------------------
// PS2 Launcher - simple UI customization
// ---------------------------------------------------------------------
// Change gUiTextColorR/G/B below (or at runtime) to recolor every
// highlighted/active piece of text and icon tint in the modern UI.
// Values are 0-255 (hex 0x00-0xFF).
//
// Default is white (0xFF, 0xFF, 0xFF), the launcher's original look.
// Example: pure yellow      -> 0xFF, 0xFF, 0x00
// Example: light blue       -> 0x40, 0xC0, 0xFF
// Example: orange           -> 0xFF, 0x80, 0x20
// ---------------------------------------------------------------------
extern u8 gUiTextColorR;
extern u8 gUiTextColorG;
extern u8 gUiTextColorB;

// Helper: same as GS_SETREG_RGBA(gUiTextColorR, gUiTextColorG, gUiTextColorB, alpha)
#define UI_TEXT_RGBA(alpha) GS_SETREG_RGBA(gUiTextColorR, gUiTextColorG, gUiTextColorB, (alpha))

// ---------------------------------------------------------------------
// Custom wallpaper (background image) for the modern UI
// ---------------------------------------------------------------------
// Set gUseCustomWallpaper to 1 to draw the embedded "wallpaper" image
// (gfx/wallpaper.png) behind the menu instead of the plain dark
// background. Set to 0 to restore the original look.
// gWallpaperDimAlpha controls how dark the overlay on top of the
// wallpaper is (0 = wallpaper fully visible, 0x80 = fully black).
// ---------------------------------------------------------------------
extern int gUseCustomWallpaper;
extern u8 gWallpaperDimAlpha;

#endif
